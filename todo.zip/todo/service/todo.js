
//get
exports.getTodo = async (res) =>{
    console.log("====service====");
    let text = "todo"
    return text;
}