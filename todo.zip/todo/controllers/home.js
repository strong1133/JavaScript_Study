exports.main = function(req, res){
    res.render('index.html')
}